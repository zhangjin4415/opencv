Object tracking API
===================

Use and/or evaluate one of 5 different visual object tracking techniques.
