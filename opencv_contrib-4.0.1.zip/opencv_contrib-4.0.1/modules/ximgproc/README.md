Extended Image Processing
=========================

- Structured Forests
- Edge Boxes
- Domain Transform Filter
- Guided Filter
- Adaptive Manifold Filter
- Joint Bilateral Filter
- Superpixels
- Graph segmentation
- Selective search from segmentation
- Paillou Filter
- Fast Line Detector
- Deriche Filter
- Pei&Lin Normalization
- Ridge Detection Filter
- Binary morphology on run-length encoded images
